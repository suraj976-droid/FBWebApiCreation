﻿namespace WebApiCreation.Models
{
    public class Emp
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string email { get; set; }

        public decimal salary { get; set; }
    }
}
